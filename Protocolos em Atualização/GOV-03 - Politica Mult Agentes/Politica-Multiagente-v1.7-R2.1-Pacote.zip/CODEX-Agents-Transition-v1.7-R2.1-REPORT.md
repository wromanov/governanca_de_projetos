# Relatório de consolidação do pacote `.codex` — v1.7-R2.1

## Escopo aplicado

A `v1.7-R2.1` consolida a arquitetura de roteamento econômico introduzida na
`v1.7-R2` após uma bateria inicial de cinco cenários de conformidade.

Não foi adicionada metodologia de `Bounded Cyclic Execution`, Work Units, retry
cíclico ou ledger de ciclo.

## Estado da validação

```text
ROUTING_CONFORMANCE_TESTS = 5/5 PASS
INITIAL_ROUTING_VALIDATION = STRONG_PASS
```

Foram validadas inicialmente as seguintes fronteiras:

- patch trivial permanece `DIRECT` quando o handoff não compensa;
- hotspot cognitivo pode ficar em Terra/High enquanto escrita mecânica e validação descem para Luna/High;
- implementação que ainda exige julgamento técnico pode usar Terra/Medium, sem forçar Luna;
- review independente continua obrigatório quando governance exige independência, mesmo com root forte;
- falha localizada e autoexplicativa não cria Triage automaticamente.

## Refinamentos de consolidação

A política passa a explicitar:

- `MULTIPLE_VALID_ROUTINGS_MAY_EXIST = YES`;
- seleção entre rotas por `EXPECTED_COST_PER_SUCCESSFUL_TASK`, confiabilidade,
  authority, eficiência de contexto e reversibilidade;
- delegação entre tiers adjacentes exige ganho líquido material;
- `ADJACENT_TIER_CAPABILITY != ADJACENT_TIER_DELEGATION_REQUIRED`;
- `TEST_FAIL != TRIAGE_REQUIRED`;
- `SPAWN_TRIAGE_BECAUSE_ANY_TEST_FAILED = PROHIBITED`;
- cenários A–E como vetores de conformidade, não receitas rígidas.

## Configuração global

- concorrência máxima de subagentes: `2`;
- máximo de writers concorrentes: `1` por política;
- fallback de subagente: `GPT-5.6 Luna`;
- fallback reasoning: `high`;
- root não é fixado no TOML;
- baseline recomendado de root: `Terra / Medium`;
- `Terra / High` para atividades com julgamento sustentado alto.

## Perfis ativos

- `luna_scout` — Scout — Luna / High — read-only
- `luna_researcher` — Researcher — Luna / XHigh — read-only
- `luna_validator` — Validator — Luna / High — workspace-write validation-only por contrato
- `luna_triage` — Triage Analyst — Luna / XHigh — read-only
- `luna_worker` — Mechanical Implementer — Luna / High — workspace-write
- `luna_scribe` — Scribe — Luna / High — workspace-write docs-only por contrato
- `terra_implementer` — Implementer — Terra / Medium — workspace-write
- `terra_reviewer` — Reviewer — Terra / High — read-only
- `terra_security` — Security Reviewer — Terra / High — read-only
- `sol_architect` — Architect — Sol / High — read-only

## Perfis de compatibilidade

- `luna_explorer` → preferir `luna_scout`
- `luna_test_analyst` → preferir `luna_validator` ou `luna_triage`

Ambos permanecem `DEPRECATED_COMPATIBILITY_PROFILE`.

## Alterações nos perfis `.codex`

### `luna_worker`

Passa a exigir explicitamente `EXPECTED_NET_ROUTING_GAIN = MATERIAL`; patch
minúsculo não deve ser delegado quando `HANDOFF_COST >= EXPECTED_TIER_SAVING`.

### `terra_implementer`

Quando o root já estiver em Terra/High, delegação para Terra/Medium exige volume
e economia suficientes para superar handoff, duplicated context e integração.

### `luna_triage`

Registra explicitamente `TEST_FAIL != TRIAGE_REQUIRED`; failure localizada e
praticamente autoexplicativa pode permanecer no root.

### `terra_reviewer`

Registra que root e reviewer podem usar o mesmo tier alto quando independência
for obrigatória; nesse caso o valor distinto é `INDEPENDENCE_VALUE`.

## Regras econômicas consolidadas

```text
ROOT_CAN_DO_IT != ROOT_SHOULD_DO_ALL_THE_WORK
LOWER_TIER_CAN_EXECUTE != LOWER_TIER_SHOULD_EXECUTE
MULTIAGENT != PARALLELISM_ONLY
EXPECTED_COST_PER_SUCCESSFUL_TASK = OPTIMIZATION_TARGET
MULTIPLE_VALID_ROUTINGS_MAY_EXIST = YES
ADJACENT_TIER_DELEGATION_REQUIRES_MATERIAL_NET_GAIN = YES
TEST_FAIL != TRIAGE_REQUIRED
```

## Validação técnica do pacote

A validação final deve confirmar:

- parse de todos os TOMLs com `tomllib`;
- integridade SHA-256/tamanho contra manifest;
- presença de exatamente um `config.toml` e 12 perfis de agentes;
- ausência de Bounded Cyclic Execution no `.codex` materializado.

## Compatibilidade de reasoning

`luna_researcher` e `luna_triage` permanecem configurados com `xhigh`. Se a
superfície específica rejeitar `xhigh` para Luna, a adaptação compatível é reduzir
somente esses perfis para `high`, sem alterar os princípios da política.

## Resultado da validação final

```text
TOML_PARSE = PASS
TOML_FILES = 13
AGENT_PROFILES = 12
CONFIG_FILES = 1
MANIFEST_SHA256_MATCH = PASS
ZIP_MANIFEST_MATCH = PASS
CYCLIC_METHODOLOGY_IN_CODEX = ABSENT
ROUTING_CONFORMANCE = 5/5 PASS
PACKAGE_VALIDATION = PASS
```
